package com.tremper.mdk;

public class TestCylinder {
    public static void main(String[] args) {
        Circle c1 = new Circle(9, "black");
        System.out.println(c1);

        Cylinder cy1 = new Cylinder(5,"Red",20);

        System.out.println(cy1);
    }
}
